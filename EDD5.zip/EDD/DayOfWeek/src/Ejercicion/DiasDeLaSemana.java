package Ejercicion;

import java.util.Calendar;

public class DiasDeLaSemana {
 
	public static void main(String[] args) {
 
		
		Calendar now = Calendar.getInstance();
 
		System.out.println("Fecha actual : " + (now.get(Calendar.MONTH) + 1)
		+ "-"
		+ now.get(Calendar.DATE)
	    + "-"
		+ now.get(Calendar.YEAR));
 

		String[] strDays = new String[]{"Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"};
 

		System.out.println("Hoy es : " + strDays[now.get(Calendar.DAY_OF_WEEK) - 1]);
	}
}

